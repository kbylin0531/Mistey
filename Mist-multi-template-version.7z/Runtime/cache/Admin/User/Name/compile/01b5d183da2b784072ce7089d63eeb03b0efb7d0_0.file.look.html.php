<?php /* Smarty version 3.1.24, created on 2015-09-08 21:52:47
         compiled from "F:/Web/Webroot/Mist/Application/Admin/User/View/Name/look.html" */ ?>
<?php
/*%%SmartyHeaderCode:3012455eee82fc77129_77124622%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01b5d183da2b784072ce7089d63eeb03b0efb7d0' => 
    array (
      0 => 'F:/Web/Webroot/Mist/Application/Admin/User/View/Name/look.html',
      1 => 1441633991,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3012455eee82fc77129_77124622',
  'variables' => 
  array (
    'lin' => 0,
    'zhao' => 0,
    'tang' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_55eee82fcd1c54_48274699',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55eee82fcd1c54_48274699')) {
function content_55eee82fcd1c54_48274699 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '3012455eee82fc77129_77124622';
?>
<!DOCTYPE html>
<extend file="toextend" />
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>

<body>

<block name="upper">
    <?php echo $_smarty_tpl->tpl_vars['lin']->value;?>

</block>

<block name="lower">
    <?php echo $_smarty_tpl->tpl_vars['zhao']->value;?>

    <?php echo $_smarty_tpl->tpl_vars['tang']->value;?>

</block>



</body>
</html><?php }
}
?>