<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/8/17
 * Time: 16:53
 */

return array(
    //模块配置 '模块名称('/分隔子模块')'=>array(...配置数组...)
    'Home'  => array(),
    'Admin/User'    => array(),

);