<?php
/**
 * Created by PhpStorm.
 * User: Lin
 * Date: 2015/8/30
 * Time: 16:24
 */
return array(
    'TEMPLATE_LAYOUT_ON'    => false,
    'TEMPLATE_LAYOUT_FILENAME'  => null,
);