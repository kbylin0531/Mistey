<?php
/**
 * Created by PhpStorm.
 * User: Lin
 * Date: 2015/8/26
 * Time: 6:58
 */
/**
 * 路由设置及URL设置
 */
return array(
    //直接路由发生在URL解析之前，直接路由如果匹配了URL字符串，则直接链接到指定的模块，否则将进行URL解析和间接路由
    'DIRECT_ROUTE_RULES'    => array(),
    //间接路由在URL解析之后
    'INDIRECT_ROUTE_RULES'   => array(

    ),
);