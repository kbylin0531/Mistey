<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/8/28
 * Time: 10:06
 */
namespace System\Core\StorageDriver;
defined('BASE_PATH') or die('No Permission!');
/**
 * Class CommonDriver 普通文件系统驱动
 * @package System\Core\StorageDriver
 */
class CommonDriver extends StorageDriver{
}