<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/9/6
 * Time: 10:00
 */
namespace System\Core\LogDriver;

/**
 * Class SaeDriver 使用SAE的日志系统进行日志记录
 * @package System\Core\LogDriver
 */
abstract class SaeDriver extends LogDriver{

}