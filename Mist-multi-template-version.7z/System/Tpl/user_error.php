<?php defined('BASE_PATH') or die('No Permission!');  ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>ERROR</title>
</head>
<body>
404 NOT FOUND!
</body>
</html>